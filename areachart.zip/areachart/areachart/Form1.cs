﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LiveCharts.WinForms;
using System.Windows.Media;
using Brushes = System.Windows.Media.Brushes;

namespace areachart
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            double[] ys1 = new double[] { 8, 11, 6, 12, 6 };
            double[] ys2 = new double[] { 6, 13, 4, 9, 11 };
            var series1 = new LiveCharts.Wpf.StackedAreaSeries()
            {
                Title = "Group A",
                Values = new LiveCharts.ChartValues<double>(ys1),
            };var series2 = new LiveCharts.Wpf.StackedAreaSeries()
            {
                Title = "Group B",
                Values = new LiveCharts.ChartValues<double>(ys2),
            };
            cartesianChart1.Series.Clear();
            cartesianChart1.Series.Add(series1);
            cartesianChart1.Series.Add(series2);
            LiveCharts.Wpf.AxesCollection yaxis = new LiveCharts.Wpf.AxesCollection();
            yaxis.Add(new LiveCharts.Wpf.Axis {Title="axis",Foreground=Brushes.Green,
            FontSize=16.0});
            cartesianChart1.AxisY = yaxis;
            cartesianChart1.Zoom = LiveCharts.ZoomingOptions.Xy;
            cartesianChart1.Hoverable = true;

        }
    }
}
